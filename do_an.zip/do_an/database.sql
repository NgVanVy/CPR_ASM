-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS hitech_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hitech_db;

-- Tạo bảng Người dùng (Users)
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(50) PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'user',
    mfaEnabled BOOLEAN DEFAULT TRUE,
    phone VARCHAR(20),
    fullName VARCHAR(100)
);

-- Tạo bảng Đơn hàng (Orders)
CREATE TABLE IF NOT EXISTS orders (
    id VARCHAR(50) PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    items TEXT NOT NULL,
    total INT NOT NULL,
    date VARCHAR(50),
    status VARCHAR(50) DEFAULT 'Đang xử lý'
);

-- Thêm 2 tài khoản mẫu (Giống hệt trên giao diện)
INSERT INTO users (id, email, password, role, mfaEnabled, phone, fullName) VALUES
('1', 'admin@group3.com', 'admin', 'admin', 1, '0999999999', 'System Admin'),
('2', 'khachvip@gmail.com', '123', 'user', 1, '0988888888', 'Nguyễn Văn VIP')
ON DUPLICATE KEY UPDATE email=email;